import { createServerClient } from '@supabase/ssr';
import { NextResponse } from 'next/server';
export async function middleware(req) {
  let res = NextResponse.next({ request: req });
  const s = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY, {
    cookies: {
      getAll: () => req.cookies.getAll(),
      setAll(list) {
        list.forEach(({ name, value }) => req.cookies.set(name, value));
        res = NextResponse.next({ request: req });
        list.forEach(({ name, value, options }) => res.cookies.set(name, value, options));
      },
    },
  });
  await s.auth.getUser(); // keeps the login session fresh
  return res;
}
export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico|api/webhook).*)'] };
