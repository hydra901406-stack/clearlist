import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
export async function GET(req) {
  const { searchParams, origin } = new URL(req.url);
  const code = searchParams.get('code');
  if (code) { const sb = await createClient(); await sb.auth.exchangeCodeForSession(code); }
  return NextResponse.redirect(origin + '/app');
}
